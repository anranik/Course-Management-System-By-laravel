<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Year;
use App\Semester;
use Illuminate\Support\Facades\Validator;

class YearController extends Controller
{
    public function index(){
        $years = Year::all();
        $semesters = Semester::all();

        return view('admin.years.index',compact('years','semesters'));
    }


    /**
     * Store semester
     */

    public function addSemester(Request $request){


        $validator = Validator::make($request->all(), [
            'semester' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }else {

            $semester = new Semester();

            $semester->semester = $request->input('semester');

            $semester->save();
            \Session::flash('msg', 'Semester Added successfully');
            return redirect()->action('YearController@index');

        }

    }

    /**
     * delete a semester
     */
    public function deleteSemester($id){
       Semester::destroy($id);
        \Session::flash('msg', 'Semester deleted successfully');
        return redirect()->action('YearController@index');
    }

    /**
     * Store semester
     */

    public function addYear(Request $request){


        $validator = Validator::make($request->all(), [
            'year' => 'required',
        ]);

        if ($validator->fails()) {
            return back()
                ->withErrors($validator)
                ->withInput();
        }else {

            $semester = new Year();

            $semester->year = $request->input('year');

            $semester->save();
            \Session::flash('msg', 'Year Added successfully');
            return redirect()->action('YearController@index');

        }

    }

    /**
     * delete a semester
     */
    public function deleteYear($id){
       Year::destroy($id);
        \Session::flash('msg', 'Year deleted successfully');
        return redirect()->action('YearController@index');
    }
}
