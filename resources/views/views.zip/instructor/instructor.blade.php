<div class="row">
    <div class="col-md-10">
        <div class="panel panel-default">
            <div class="panel-heading">Instructor Dashboard</div>

            <div class="panel-body">

                <table class="table table-bordered datatable">
                    <tr>
                        <th>Course ID</th>
                        <th>Course Name</th>
                        <th>Status</th>
                        <th>Course Builder</th>
                    </tr>

                    {{--@foreach($data as $single)--}}
                    {{--<tr>--}}
                        {{--<td>{{$single->id}}</td>--}}

                    {{--</tr>--}}
                    {{--@endforeach--}}
                </table>
            </div>
        </div>
    </div>
</div>