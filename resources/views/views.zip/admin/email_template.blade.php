

    {{--section for instructor--}}
    @can('users_manage')
        <table class="table table-bordered">
            <tr>
                <td>Request: New eCourse:</td>
                <td><textarea name="Demo" id="" cols="30" rows="10"> Text goeas here</textarea></td>
            </tr>
            <tr>
                <td>Request: Reactive eCourse:</td>
                <td><textarea name="Demo" id="" cols="30" rows="10"> Text goeas here</textarea></td>
            </tr>
            <tr>
                <td>Assign New eCourse:</td>
                <td><textarea name="Demo" id="" cols="30" rows="10"> Text goeas here</textarea></td>
            </tr>
            <tr>
                <td>eCourse Activated Successfully (New-Renew)</td>
                <td><textarea name="Demo" id="" cols="30" rows="10"> Text goeas here</textarea></td>
            </tr>
        </table>
    @endcan
    {{--end section for instructor--}}


